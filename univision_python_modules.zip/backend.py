
# backend.py
# Vision backend pipeline for vehicle number plate detection

import cv2
from ultralytics import YOLO
import easyocr

vehicle_model = YOLO("yolov8n.pt")
plate_model = YOLO("license_plate_detector.pt")
ocr = easyocr.Reader(['en'])

def detect_vehicles(frame):
    results = vehicle_model(frame)
    vehicles = []
    for r in results:
        for box in r.boxes.xyxy:
            x1,y1,x2,y2 = map(int, box)
            vehicles.append(frame[y1:y2, x1:x2])
    return vehicles

def detect_plates(vehicle_img):
    results = plate_model(vehicle_img)
    plates = []
    for r in results:
        for box in r.boxes.xyxy:
            x1,y1,x2,y2 = map(int, box)
            plates.append(vehicle_img[y1:y2, x1:x2])
    return plates

def recognize_plate(plate_img):
    text = ocr.readtext(plate_img)
    if len(text) > 0:
        return text[0][1]
    return None
