
# analytics.py
# Traffic analytics

import sqlite3
import pandas as pd
import matplotlib.pyplot as plt

conn = sqlite3.connect("toll_gate.db")

def traffic_analysis():
    df = pd.read_sql_query("SELECT * FROM vehicles", conn)

    df['timestamp'] = pd.to_datetime(df['timestamp'])
    df['hour'] = df['timestamp'].dt.hour

    traffic = df.groupby('hour').size()

    plt.plot(traffic.index, traffic.values)
    plt.xlabel("Hour")
    plt.ylabel("Vehicle Count")
    plt.title("Traffic Flow")
    plt.show()

if __name__ == "__main__":
    traffic_analysis()
