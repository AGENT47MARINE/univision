
# communication_api.py
# Backend API server

from fastapi import FastAPI
import uvicorn
from datetime import datetime

app = FastAPI()

@app.get("/detect")
def detect():
    # dummy example output
    return {
        "detections":[
            {"plate":"WB34AB1234","time":str(datetime.now())}
        ]
    }

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
