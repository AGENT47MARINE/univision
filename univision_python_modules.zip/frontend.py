
# frontend.py
# Simple UI dashboard

import tkinter as tk
import requests

API = "http://127.0.0.1:8000/detect"

def detect():
    r = requests.get(API)
    data = r.json()
    text.delete("1.0", tk.END)

    for d in data["detections"]:
        text.insert(tk.END, f"{d['plate']}  {d['time']}\n")

root = tk.Tk()
root.title("Toll Gate Dashboard")

btn = tk.Button(root, text="Run Detection", command=detect)
btn.pack()

text = tk.Text(root, height=20, width=50)
text.pack()

root.mainloop()
