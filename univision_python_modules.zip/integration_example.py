
# integration_example.py
# Example integration with database or external systems

import sqlite3

conn = sqlite3.connect("toll_gate.db")
cursor = conn.cursor()

cursor.execute(
'''
CREATE TABLE IF NOT EXISTS vehicles(
plate TEXT,
timestamp TEXT
)
'''
)

def save_vehicle(plate, timestamp):
    cursor.execute(
        "INSERT INTO vehicles VALUES (?,?)",
        (plate, timestamp)
    )
    conn.commit()

if __name__ == "__main__":
    save_vehicle("WB34AB1234","2026-03-09 13:00:00")
